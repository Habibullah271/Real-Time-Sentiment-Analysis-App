import facebook
import streamlit as st
from PIL import Image
import pytesseract
from main import calculatesentiment
import time

# Initialize Facebook Graph API with the updated access token
graph = facebook.GraphAPI(access_token="EAAFoXe0jfxEBOZCdG1xOmS9j3JprZAbL6gbAdVqFAhnQZAZCPMpvBPrFvAZCVFjgljICWA0DekZBZCxOXUThyVLwCivZB7P2w1R7H3eCMmyvu0z8LOtm9mFs2BjP1J3LYdhwIoKwmK8FIruKHvGD9i7ReEzya47SZAvwVQjPklOIqhtMJq6OKXxK5d8ekVHSgBdZA0pXgYMakQZCzphEnOzLV6gj1Dk")

# Customizing title background color and adding emoji
temp = """
    <div style="background-color:green;padding:10px">
    <h2 style="color:white; text-align:center;"> Real Time Sentiment Analysis 😄😢 </h2>
    </div>
"""
st.markdown(temp, unsafe_allow_html=True)

# Function to perform sentiment analysis
def perform_sentiment_analysis(comments):
    combined_text = "\n".join(comments)
    result = calculatesentiment(combined_text)
    st.write("Sentiment Analysis Result:")
    for label, score in result.items():
        st.write(f"{label}: {score:.4f}")

# Function to extract text from image using OCR
def extract_text_from_image(image):
    text = pytesseract.image_to_string(image)
    return text

# Function to fetch comments from Facebook post
def fetch_comments(post_id):
    comments = graph.get_connections(id=post_id, connection_name='comments')
    comment_texts = []
    for comment in comments['data']:
        comment_text = comment.get('message', '')
        if comment_text:
            comment_texts.append(comment_text)
    return comment_texts

# Displaying result in a column layout
col1, col2 = st.columns([1, 1])

# Your page's post ID
post_id = "122098558706257282"

# Option to upload file
uploaded_file = st.file_uploader("Upload a file", type=["txt", "csv", "json", "png", "jpg"])

if uploaded_file is not None:
    if uploaded_file.type.startswith('image'):
        img = Image.open(uploaded_file)
        input_text = extract_text_from_image(img)
        perform_sentiment_analysis([input_text])
    else:
        input_text = uploaded_file.getvalue().decode("utf-8")
        perform_sentiment_analysis([input_text])
else:
    if st.button("Fetch Comments"):
        comments = fetch_comments(post_id)
        perform_sentiment_analysis(comments)

# Periodically fetch comments after every 10 seconds
empty_slot = st.empty()
while True:
    empty_slot.text("Next update in 10 seconds...")
    comments = fetch_comments(post_id)
    perform_sentiment_analysis(comments)
    time.sleep(10)